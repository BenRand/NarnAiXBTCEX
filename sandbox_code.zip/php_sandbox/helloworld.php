<html>
	<head>
		<title>Hello World!</title>
	</head>
	<body>
		<?php 
			// single-line comments can be like this
			# or even like this
			/* multi-line comments can 
				be like this */ ?>
		<h1>Examples</h1>
		<?php echo "Hello World!"; ?><br />
		<?php
			// The semicolon at the end of the statement is important!
		?>
		<?php 
			// print works like echo
			print "Hello World!";
		?><br />
		
		<?php
			// concatenation
			echo "Hello" . " World!<br />";
			
			// simple math
			echo 2 + 3;
			
		?><br />
	</body>
</html>
