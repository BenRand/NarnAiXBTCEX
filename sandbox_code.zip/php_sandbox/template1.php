<html>
	<head>
	  <title><?php echo $page_title; ?></title>
	</head>
	<body>
	
		<h1><?php echo $page_title; ?></h1>

		<p><?php echo $content; ?></p>
		
	</body>
</html>
