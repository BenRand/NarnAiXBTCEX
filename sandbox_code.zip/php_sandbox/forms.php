<html>
	<head>
		<title>Forms</title>
	</head>
	<body>
	<form action="process.php" method="post">
		Username: <input type="text" name="username" value="" />
		<br />
		Password: <input type="password" name="password" value="" />
		<br />
		<input type="submit" name="submit" value="Submit" />
	</form>
	</body>
</html>