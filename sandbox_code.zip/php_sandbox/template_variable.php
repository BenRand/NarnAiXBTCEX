<?php

  $page_title = "Template Test";
  $content = "This is a test of templating using variables.";

  include('template1.php');
?>
