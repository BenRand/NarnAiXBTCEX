<?php 
/*	WARNING:  NEVER include this file on your production machine
	It's very useful for development but it also gives away WAY too much 
	information about your system if anyone got access to it.
*/
	phpinfo(); 
?>